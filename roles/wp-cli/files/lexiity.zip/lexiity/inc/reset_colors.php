<?php
             require( '../../../../wp-load.php' );
            
            update_option(tk_theme_name.'_colors_body_color', 'EFEFEF');
            update_option(tk_theme_name.'_colors_header_color', 'FFF');
            update_option(tk_theme_name.'_colors_navigation_color', 'FFFFFF');
            update_option(tk_theme_name.'_colors_title_color', '000000');
            update_option(tk_theme_name.'_colors_paragraph_color', '323232');
            update_option(tk_theme_name.'_colors_link_color', 'a1a1a1');
            update_option(tk_theme_name.'_colors_link_hover_color', 'FFD500');
            update_option(tk_theme_name.'_colors_footer_title_color', '000000');
            update_option(tk_theme_name.'_colors_footer_paragraph_color', '323232');
            update_option(tk_theme_name.'_colors_copyright_color', '323232');




?>