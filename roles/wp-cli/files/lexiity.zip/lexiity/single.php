<?php 
the_tags();
////silence is golden ?>