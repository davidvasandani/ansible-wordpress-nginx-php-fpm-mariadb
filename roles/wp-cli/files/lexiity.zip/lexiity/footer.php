<?php wp_footer();?>





  <?php
        $copyright = get_theme_option(tk_theme_name.'_general_footer_copy');
        if(empty($copyright)) {
            $copyright = 'Copyright Information Goes Here 2012. All Rights Reserved. Designed by  Themeskingdom';
        }
    ?>


    <!-- FOOTER -->
    <div class="footer left">
        <div class="wrapper">

            <div class="content-center left">
                <div class="footer-copyright left"><?php echo $copyright; ?></div><!--/footer-copyright-->
            </div><!--/content-center-->

            <div class="content-down left"><img src="<?php echo get_template_directory_uri(); ?>/style/img/content-down.png" alt="img" title="img" /></div><!--/content-down-->
        </div><!--/wrapper-->
    </div><!--/footer-->



</div><!--/container-->
</body>
</html>