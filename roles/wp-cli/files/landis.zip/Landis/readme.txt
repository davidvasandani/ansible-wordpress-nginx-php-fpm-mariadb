Theme Name: Landis 
Support URI: http://www.themeskingdom.com/
Description: Landis, a premium Wordpress theme by Themes Kingdom. Wordpress conversion by Themes Kingdom.
Author: Themes Kingdom
Author URI: http://www.themeskingdom.com/
Version: 1.0
Tags: red, blue, green, brown, fixed-width
License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html