<?php 
	require_once (GD_FUNCTIONS . 'admin/landis.php'); 

	
?>