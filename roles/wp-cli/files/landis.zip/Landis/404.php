<?php 

get_header(); ?>

<div id="front_page_container">
	<div id="featured">



				
							
				<div id="front_left_cell">
					<span class="line shortcode-line"></span>
					<span class="page404">404</span><span class="page404span">Looks like the page you we’re looking for doesn’t exist. Sorry about that.</span>
					<span class="line shortcode-line"></span>
				</div><!--close front_left_cell-->
			
			</div><!--close continer-->
		</div><!--close front_page-->
</div><!--front_page_container-->
<?php get_footer(); ?>