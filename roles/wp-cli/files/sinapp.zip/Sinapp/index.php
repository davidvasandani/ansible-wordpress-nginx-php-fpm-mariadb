<?php get_header(); ?>

    <!-- CONTENT -->
    <div class="content left">


        <div class="stay-content left">
            <div class="wrapper">
                <span>Stay Tuned</span>
                <div class="facebook-content left"><div class="fb-like" data-href="<?php home_url(); ?>" data-send="false" data-layout="button_count" data-width="450" data-show-faces="true"></div></div><!--/facebook-content-->
                <div class="twitter-content left"><a href="https://twitter.com/share" class="twitter-share-button" data-url="<?php echo home_url(); ?>">Tweet</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script></div><!--/twitter-content-->
                <div class="gmail-content left">
<!-- Place this tag in your head or just before your close body tag -->
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>

<!-- Place this tag where you want the +1 button to render -->
<g:plusone size="medium" href="<?php home_url(); ?>"></g:plusone>

                </div><!--/gmail-content-->
                <div class="pin-content left"><a href="http://pinterest.com/pin/create/button/?url=<?php home_url(); ?>&media=<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) )?>" class="pin-it-button" count-layout="inline"><img border="0" src="//assets.pinterest.com/images/PinExt.png" title="Pin It" /></a></div><!--/pin-content-->
            </div><!--/wrapper-->
        </div><!--/wrapper-->

        <div class="wrapper">

            <div class="shortcodes left">


                    <?php
                        /* Run the loop to output the page.
                                                 * If you want to overload this in a child theme then include a file
                                                 * called loop-page.php and that will be used instead.
                        */
                        //get_template_part( 'loop', 'page' );
                        wp_reset_query();
                        if ( have_posts() ) : while ( have_posts() ) : the_post();
                                the_content();
                            endwhile;
                        else:
                        endif;
                        wp_reset_query();
                        ?>



            </div><!-- /shortcodes-right -->

        </div><!--/wrapper-->


    </div><!--/content-->





            
<?php get_footer(); ?>