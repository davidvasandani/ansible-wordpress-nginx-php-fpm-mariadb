jQuery(document).ready(function(){

    // NIVO SLIDER
    jQuery('#slider').nivoSlider({
        effect:'fade', //Specify sets like: 'fold,fade,sliceDown'
        slices:15,
        animSpeed:500, //Slide transition speed
        pauseTime:3000,
        startSlide:0, //Set starting Slide (0 index)
        directionNav:false, //Next & Prev
        directionNavHide:false, //Only show on hover
        controlNav:false, //1,2,3...
        controlNavThumbs:true, //Use thumbnails for Control Nav
        controlNavThumbsFromRel:true, //Use image rel for thumbs
        controlNavThumbsSearch: '.jpg', //Replace this with...
        controlNavThumbsReplace: '_thumb.jpg', //...this in thumb Image src
        keyboardNav:true, //Use left & right arrows
        pauseOnHover:false, //Stop animation while hovering
        manualAdvance:false, //Force manual transitions
        captionOpacity:false, //Universal caption opacity
        beforeChange: function(){},
        afterChange: function(){},
        slideshowEnd: function(){}, //Triggers after all slides have been shown
        lastSlide: function(){}, //Triggers when last slide is shown
        afterLoad: function(){} //Triggers when slider has loaded
    });





       jQuery(".hider").toggle(function() {
            jQuery(".demo_wrap").animate({"left": "+=230px", "opacity" : "1"}, "slow");
            jQuery(".hider").animate({"left": "+=230px", "opacity" : "1"}, "slow");
           var checker='out';

                }, function() {
            jQuery(".demo_wrap").animate({"left": "-=230px", "opacity" : "1"}, "slow");
            jQuery(".hider").animate({"left": "-=230px", "opacity" : "1"}, "slow");
            var checker='in';

});

       jQuery(".hiderfont").toggle(function() {

            jQuery(".font-picker").animate({"left": "+=230px", "opacity" : "1"}, "slow");
            jQuery(".hiderfont").animate({"left": "+=230px", "opacity" : "1"}, "slow");
           var  fontchecker = 'out';


                }, function() {

                    jQuery(".font-picker").animate({"left": "-=230px", "opacity" : "1"}, "slow");
                    jQuery(".hiderfont").animate({"left": "-=230px", "opacity" : "1"}, "slow");
             var  fontchecker = 'in';


});









});



