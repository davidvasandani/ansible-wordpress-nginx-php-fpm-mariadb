<?php wp_footer(); ?>






     <div class="twitter-holder">

				<?php // Your twitter username.
                                $theme = wp_get_theme();
				$username = get_theme_option($theme->name.'_general_twitter');

				if(empty($username)) {$username="themeskingdom";}

				// Suffix - some text you want display after your latest tweet. (Same rules as the prefix.)
				$suffix = "";

				$feed = "http://search.twitter.com/search.atom?q=from:" . $username . "&rpp=1";
				$curl_handle = curl_init($feed);
					curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT,10);
					curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
					$content = "";
					$content = curl_exec($curl_handle);
					curl_close($curl_handle);
					$parsed = "";
				if(isset($content)){
				$result = new SimpleXMLElement($content);

				$parsed = $result->entry->content;
				}

					if(!empty($parsed)){ ?>


         <div class="footer_twitter">



                     <div class="footer-twitter left">
            <div class="wrapper">

                    <div class="twitter-dialog">
                        <table class="twitter_table">
                            <thead>
                                <tr><th colspan="2"><div class="twitter-dialog-top"> </div></th></tr>
                            </thead>    
                            <tbody>
                                <tr>
                                    <td style="width:40px;">
                                         <a href="http://twitter.com/<?php echo get_theme_option('general_twitter');?>" class="twitter-link" title="Follow me on Twitter"><span class="bird"></span></a>
                                    </td>
                                    <td class="twitter-dialog-td-p">	<?php echo $parsed.stripslashes($suffix);  ?></td>
                                </tr>
                                <tr>
                                    <td colspan="2"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div><!--/ftwitter-dialog-->   

            </div><!--/wrapper-->
        </div><!--/footer-twitter-->



					</div>
					<?php } ?>
		</div><!--twitter holder-->






    <!-- FOOTER -->
    <div class="footer left">



        <div class="footer-copyright left">
            <div class="wrapper">
                <?php

                $theme = wp_get_theme();
                
                $copyright =  get_theme_option($theme->name.'_general_copyright_text'); ?>
               
                <?php if(!empty($copyright)) { echo $copyright;} ?>
            </div><!--/wrapper-->
        </div><!--/footer-copyright-->

    </div><!--/footer-->



</div><!--/container-->
</body>
</html>