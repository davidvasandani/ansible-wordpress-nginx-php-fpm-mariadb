<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html <?php language_attributes(); ?> xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">

	<title><?php bloginfo('name'); ?> <?php wp_title(); ?></title>

	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />	
	<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats please -->

	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

   
        <link rel="stylesheet" media="screen" href="<?php echo get_template_directory_uri() . "/script/pirobox/css/demo5/style.css"; ?>" type="text/css"/>
        <link rel="stylesheet" media="screen" href="<?php echo get_template_directory_uri() . "/script/nivoSlider/nivo-slider.css"; ?>" type="text/css" />

 
<?php

        /*************************************************************/
        /*Test user agent and load css for it***************************/
        /*************************************************************/


        $browser = $_SERVER['HTTP_USER_AGENT'];

        // Macintosh
        $mac = strpos($browser, 'Macintosh') ? true : false;

        // Windows
        $win = strpos($browser, 'Windows') ? true : false;





        if (strpos($browser, 'Safari')) {
            ?>
        <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/safari.css" type="text/css" />
            <?php
            if(!empty($win)) {
                if($win == Windows) { ?>
                    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/win-safari.css" type="text/css" />
                <?php
                }
            }
        }

        if (strpos($browser, 'MSIE 8.0')) {
            ?>
                <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/ie8.css" type="text/css" />
            <?php
        }

        if (strpos($browser, 'MSIE 9.0')) {
            ?>
        <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/ie9.css" type="text/css" />
            <?php
        }

        if (strpos($browser, 'Chrome')) {
            ?>
                <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/chrome.css" type="text/css" />
            <?php
            if(!empty($win)) {
                if($win == Windows) { ?>
                    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/win-chrome.css" type="text/css" />
                <?php
                }
            }
        }

        if (strpos($browser, 'pera')) {
            ?>
                <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/opera.css" type="text/css" />
            <?php
            if(!empty($win)) {
                if($win == Windows) { ?>
                    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/win-opera.css" type="text/css" />
                <?php
                }
            }
        }

        if (strpos($browser, 'Firefox')) {
            ?>
                <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/firefox.css" type="text/css" />
            <?php
            if(!empty($win)) {
                if($win == Windows) { ?>
                    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/win-firefox.css" type="text/css" />
                <?php
                }
            }
        }

?>

               
                    

        <?php

        /*************************************************************/
        /************LOAD SCRIPTS***********************************/
        /*************************************************************/


            wp_deregister_script('jquery');
            wp_register_script('jquery', get_template_directory_uri().'/script/jquery/jquery-1.7.2.min.js');
            wp_enqueue_script('jquery');
            wp_enqueue_script('ajaxpager', get_template_directory_uri() . '/script/quickpager/quickpager.jquery.js');
            wp_enqueue_script('my-commons', get_template_directory_uri().'/script/common.js' );
            wp_enqueue_script('pirobox', get_template_directory_uri().'/script/pirobox/js/pirobox.js' );
            wp_enqueue_script('elastic', get_template_directory_uri().'/script/elastic/jquery.elastic.source.js' );
            wp_enqueue_script('jscolor', get_template_directory_uri().'/script/jscolor/jscolor.js' );
            wp_enqueue_script('NivoSlider', get_template_directory_uri().'/script/nivoSlider/jquery.nivo.slider.js' );
   
            if ( is_singular() ) wp_enqueue_script( 'comment-reply' );
        ?>

        <?php $favicon = get_theme_option('Inkland_general_favicon'); if(empty($favicon)) { $favicon = get_template_directory_uri()."/style/img/favicon.ico"; }?>
        <link rel="shortcut icon" href="<?php echo $favicon;?>" />

        
        <?php

         $g_analitics = get_theme_option('Inkland_general_google_analytics');

         if( isset ($g_analitics) && $g_analitics != ''){
             echo $g_analitics;
         }

        ?>
        <?php
            $theme = wp_get_theme();
            
            $header_font = get_theme_option($theme->name.'_fonts_header_text_font');
            $text_font = get_theme_option($theme->name.'_fonts_paragraph_font');
            $header_colors = get_theme_option($theme->name.'_colors_header_text_color');
            $headings_colors = get_theme_option($theme->name.'_colors_heading_text_color');
            $paragraph_colors = get_theme_option($theme->name.'_colors_paragraph_text_color');
            $heading_paragraph_colors = get_theme_option($theme->name.'_colors_heading_paragraph_text_color');
            $share_bar = get_theme_option($theme->name.'_colors_share_buttons_background');
            $content_back = get_theme_option($theme->name.'_colors_content_background');
            $twitter_back = get_theme_option($theme->name.'_colors_twitter_back');
            $footer_back  = get_theme_option($theme->name.'_colors_footer_back');
            $twitter_color  = get_theme_option($theme->name.'_colors_twitter_color');
            $phone_color = get_theme_option($theme->name.'_colors_phone_color');
            $headings_font = get_theme_option($theme->name.'_fonts_headings_font');
            $content_text_font = get_theme_option($theme->name.'_fonts_content_paragraph_font');
            $linkcolor = get_theme_option($theme->name.'_colors_links_color');
            $border_color = get_theme_option($theme->name.'_colors_border_color');

            if(empty($phone_color)) {
                $phone_color = 'white';
            }
            ?>

        <?php if($header_font == 'Lobster13Regular') { ?>
            <style type="text/css">
                .text-header h1 {
                    text-transform:none !important;
                }
            </style>
            <?php } ?>
       <?php  if ($text_font == 'Lobster13Regular') { ?>
            <style type="text/css">
                .text-header p, .shortcodes p, .cell_text, .shortcodes ul li, .wrapper {
                    text-transform:none !important;
                }
            </style>
            <?php } ?>
        <?php if ($content_text_font == 'Lobster13Regular') { ?>
            <style type="text/css">
               .shortcodes p, .cell_text, .shortcodes ul li, .wrapper, .twitter-dialog-td-p, .wrapper, blockquote p {
                    text-transform:none !important;
                }
            </style>
            <?php } ?>
              <?php if ($headings_font == 'Lobster13Regular') { ?>
            <style type="text/css">
              .shortcodes h1, .shortcodes h2, .shortcodes h3, .shortcodes h4, .shortcodes h5, .shortcodes h6, blockquote p {
                    text-transform:none !important;
                }
            </style>
<?php } ?>





             <style type="text/css">
                        @font-face {
                            font-family: 'DosisMedium';
                            src: url('<?php echo get_template_directory_uri(); ?>/font/dosis-medium-webfont.eot');
                            src: url('<?php echo get_template_directory_uri(); ?>/font/dosis-medium-webfont.eot?#iefix') format('embedded-opentype'),
                                 url('<?php echo get_template_directory_uri(); ?>/font/dosis-medium-webfont.woff') format('woff'),
                                 url('<?php echo get_template_directory_uri(); ?>/font/dosis-medium-webfont.ttf') format('truetype'),
                                 url('<?php echo get_template_directory_uri(); ?>/font/dosis-medium-webfont.svg#DosisMedium') format('svg');
                            font-weight: normal;
                            font-style: normal;

                        }
                    </style>

            <?php if(($header_font == 'GoodDogRegular') || ($text_font == 'GoodDogRegular') || ($text_font == 'GoodDogRegular') || ($headings_font == 'GoodDogRegular') || ($content_text_font == 'GoodDogRegular') ) { ?>

                    <style type="text/css">
                    @font-face {
                        font-family: 'GoodDogRegular';
                        src: url('<?php echo get_template_directory_uri(); ?>/font/gooddog/GoodDog-webfont.eot');
                        src: url('<?php echo get_template_directory_uri(); ?>/font/gooddog/GoodDog-webfont.eot?#iefix') format('embedded-opentype'),
                             url('<?php echo get_template_directory_uri(); ?>/font/gooddog/GoodDog-webfont.woff') format('woff'),
                             url('<?php echo get_template_directory_uri(); ?>/font/gooddog/GoodDog-webfont.ttf') format('truetype'),
                             url('<?php echo get_template_directory_uri(); ?>/font/gooddog/GoodDog-webfont.svg#GoodDogRegular') format('svg');
                        font-weight: normal;
                        font-style: normal;

                    }
                    </style>
            <?php } ?>


        <?php if(($header_font == 'NeoRetroDrawRegular') || ($text_font == 'NeoRetroDrawRegular') || ($text_font == 'NeoRetroDrawRegular') || ($headings_font == 'NeoRetroDrawRegular') || ($content_text_font == 'NeoRetroDrawRegular') ) { ?>
                    <style type="text/css">
                    @font-face {
                        font-family: 'NeoRetroDrawRegular';
                        src: url('<?php echo get_template_directory_uri(); ?>/font/neoretrodraw/NEORD___-webfont.eot');
                        src: url('<?php echo get_template_directory_uri(); ?>/font/neoretrodraw/NEORD___-webfont.eot?#iefix') format('embedded-opentype'),
                             url('<?php echo get_template_directory_uri(); ?>/font/neoretrodraw/NEORD___-webfont.woff') format('woff'),
                             url('<?php echo get_template_directory_uri(); ?>/font/neoretrodraw/NEORD___-webfont.ttf') format('truetype'),
                             url('<?php echo get_template_directory_uri(); ?>/font/neoretrodraw/NEORD___-webfont.svg#NeoRetroDrawRegular') format('svg');
                        font-weight: normal;
                        font-style: normal;

                    }
                    </style>
        <?php } ?>



                    <style type="text/css">
                    @font-face {
                        font-family: 'ChunkFiveRegular';
                        src: url('<?php echo get_template_directory_uri(); ?>/font/chunkfive/Chunkfive-webfont.eot');
                        src: url('<?php echo get_template_directory_uri(); ?>/font/chunkfive/Chunkfive-webfont.eot?#iefix') format('embedded-opentype'),
                             url('<?php echo get_template_directory_uri(); ?>/font/chunkfive/Chunkfive-webfont.woff') format('woff'),
                             url('<?php echo get_template_directory_uri(); ?>/font/chunkfive/Chunkfive-webfont.ttf') format('truetype'),
                             url('<?php echo get_template_directory_uri(); ?>/font/chunkfive/Chunkfive-webfont.svg#ChunkFiveRegular') format('svg');
                        font-weight: normal;
                        font-style: normal;
                    }
                    </style>
        


        <?php if(($header_font == 'SansationRegular') || ($text_font == 'SansationRegular') || ($text_font == 'SansationRegular') || ($headings_font == 'SansationRegular') || ($content_text_font == 'SansationRegular') ) { ?>
                    <style type="text/css">
                    @font-face {
                        font-family: 'SansationRegular';
                        src: url('<?php echo get_template_directory_uri(); ?>/font/sansation/Sansation_Regular-webfont.eot');
                        src: url('<?php echo get_template_directory_uri(); ?>/font/sansation/Sansation_Regular-webfont.eot?#iefix') format('embedded-opentype'),
                             url('<?php echo get_template_directory_uri(); ?>/font/sansation/Sansation_Regular-webfont.woff') format('woff'),
                             url('<?php echo get_template_directory_uri(); ?>/font/sansation/Sansation_Regular-webfont.ttf') format('truetype'),
                             url('<?php echo get_template_directory_uri(); ?>/font/sansation/Sansation_Regular-webfont.svg#SansationRegular') format('svg');
                        font-weight: normal;
                        font-style: normal;
                    }
                    </style>
            <?php } ?>


         <?php if(($header_font == 'MuseoSlab500Regular') || ($text_font == 'MuseoSlab500Regular') || ($text_font == 'MuseoSlab500Regular') || ($headings_font == 'MuseoSlab500Regular') || ($content_text_font == 'MuseoSlab500Regular') ) { ?>
                    <style type="text/css">
                    @font-face {
                        font-family: 'MuseoSlab500Regular';
                        src: url('<?php echo get_template_directory_uri(); ?>/font/museo/Museo_Slab_500-webfont.eot');
                        src: url('<?php echo get_template_directory_uri(); ?>/font/museo/Museo_Slab_500-webfont.eot?#iefix') format('embedded-opentype'),
                             url('<?php echo get_template_directory_uri(); ?>/font/museo/Museo_Slab_500-webfont.woff') format('woff'),
                             url('<?php echo get_template_directory_uri(); ?>/font/museo/Museo_Slab_500-webfont.ttf') format('truetype'),
                             url('<?php echo get_template_directory_uri(); ?>/font/museo/Museo_Slab_500-webfont.svg#MuseoSlab500Regular') format('svg');
                        font-weight: normal;
                        font-style: normal;
                    }
                    </style>
            <?php } ?>


         <?php if(($header_font == 'OpenSansRegular') || ($text_font == 'OpenSansRegular') || ($text_font == 'OpenSansRegular') || ($headings_font == 'OpenSansRegular') || ($content_text_font == 'OpenSansRegular') ) { ?>
                    <style type="text/css">
                    @font-face {
                        font-family: 'OpenSansRegular';
                        src: url('<?php echo get_template_directory_uri(); ?>/font/opensans/OpenSans-Regular-webfont.eot');
                        src: url('<?php echo get_template_directory_uri(); ?>/font/opensans/OpenSans-Regular-webfont.eot?#iefix') format('embedded-opentype'),
                             url('<?php echo get_template_directory_uri(); ?>/font/opensans/OpenSans-Regular-webfont.woff') format('woff'),
                             url('<?php echo get_template_directory_uri(); ?>/font/opensans/OpenSans-Regular-webfont.ttf') format('truetype'),
                             url('<?php echo get_template_directory_uri(); ?>/font/opensans/OpenSans-Regular-webfont.svg#OpenSansRegular') format('svg');
                        font-weight: normal;
                        font-style: normal;

                    }
                    </style>
        <?php } ?>


        <?php if(($header_font == 'Lobster13Regular') || ($text_font == 'Lobster13Regular') || ($text_font == 'Lobster13Regular') || ($headings_font == 'Lobster13Regular') || ($content_text_font == 'Lobster13Regular') ) { ?>
                    <style type="text/css">
                    @font-face {
                        font-family: 'Lobster13Regular';
                        src: url('<?php echo get_template_directory_uri(); ?>/font/lobster/Lobster_1.3-webfont.eot');
                        src: url('<?php echo get_template_directory_uri(); ?>/font/lobster/Lobster_1.3-webfont.eot?#iefix') format('embedded-opentype'),
                             url('<?php echo get_template_directory_uri(); ?>/font/lobster/Lobster_1.3-webfont.woff') format('woff'),
                             url('<?php echo get_template_directory_uri(); ?>/font/lobster/Lobster_1.3-webfont.ttf') format('truetype'),
                             url('<?php echo get_template_directory_uri(); ?>/font/lobster/Lobster_1.3-webfont.svg#Lobster13Regular') format('svg');
                        font-weight: normal;
                        font-style: normal;
                    }

                    </style>
        <?php } ?>





        <style type="text/css">

            .text-header h1, .stay-content span, .store-header span, .shortcodes h1, .shortcodes h2, .shortcodes h3, .shortcodes h4, .shortcodes h5, .shortcodes h6 {
                  font-family:'<?php echo $header_font ?>';
                  color:#<?php echo $header_colors ?>;
            }

            .shortcodes h1, .shortcodes h2, .shortcodes h3, .shortcodes h4, .shortcodes h5, .shortcodes h6, .stay-content span {
                  color:#<?php echo $headings_colors ?>;                
            }

            .shortcodes h1, .shortcodes h2, .shortcodes h3, .shortcodes h4, .shortcodes h5, .shortcodes h6, .blockquote p {
                font-family:<?php echo $headings_font ?>;
}

            .text-header p, .shortcodes p, .cell_text, .shortcodes ul li, .wrapper {
                    font-family:'<?php echo $text_font; ?>';
                    color:#<?php echo $paragraph_colors; ?>;
            }

            .text-header p {
                color:#<?php echo $heading_paragraph_colors; ?>;
            }

            .header {
                border-color:#<?php echo $border_color ?>;
            }

            .stay-content {
                background-color:#<?php echo $share_bar; ?>;
            }

            .content {
                background-color:#<?php echo $content_back ?>;
            }

            .footer-twitter {
                background-color:#<?php echo $twitter_back; ?>;
            }

            .footer-copyright {
                background-color:#<?php echo $footer_back; ?>;
            }

            .twitter-dialog-td-p {
                color:#<?php echo $twitter_color; ?>;
            }
            .bg-phone-white {
                width: 345px;
                height: 680px;
                background:url("<?php echo get_template_directory_uri(); ?>/style/img/bg-phone-<?php echo $phone_color; ?>.png") no-repeat left top;
                position: relative;
                z-index: 99;
            }

            .shortcodes p, .cell_text, .shortcodes ul li, .wrapper, .twitter-dialog-td-p, .wrapper {
                font-family:'<?php echo $content_text_font; ?>';
            }

            a {
                color:#<?php echo $linkcolor; ?>;
                }



        </style>



<?php wp_head(); ?>

</head>
<body <?php body_class(); ?>>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=113020565471594";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>


    <?php
   

     $logo = get_theme_option($theme->name.'_general_header_logo');
     $app_store_time = get_theme_option($theme->name.'_general_app_store');
     $headline = get_theme_option($theme->name.'_general_text_heading');
     $site_text = get_theme_option($theme->name.'_general_site_text');


     $newsletter_type = get_theme_option($theme->name.'_newsletter_newsletter_service');
     $sendloop_username = get_theme_option($theme->name.'_newsletter_sendloop_username');
     $sendloop_list = get_theme_option($theme->name.'_newsletter_sendloop_list_id');

     $app_link = get_theme_option($theme->name.'_general_app_link');

                        ?>

<div id="container">

    <?php $header_image = header_image(); ?>

    <!-- HEADER -->
    <div class="header left"  <?php if(!empty($header_image)) {?> style="background:url('<?php header_image(); ?>') no-repeat  center;" <?php }  ?>>
        <div class="wrapper">
            <div class="heighter">

            <!--LOGO-->
            <div class="logo left">

                   <?php
                       
                        if(empty($logo)) {
                        $logo = get_template_directory_uri()."/style/img/logo.png";
                     }?>
                <a href="<?php echo home_url(); ?>"><img src="<?php echo $logo; ?>" alt='logo' /></a>

            </div><!--/logo-->

    <?php
       

       
     ?>
    <?php if(empty($app_link)) { ?>
        <?php if(!empty($app_store_time)) { ?>
            <div class="store-header right">
                <span><?php echo $app_store_time; ?></span>
                <img src="<?php echo get_template_directory_uri(); ?>/style/img/store-img.png"/>
            </div><!--/store-header-->
        <?php } ?>
    <?php } ?>
            <div class="text-slider-header left">

                <div class="text-header left">
                    <?php if(!empty($headline)){ ?>
                        <h1><?php echo $headline; ?></h1>
                    <?php } ?>
                    <?php if(!empty($site_text)) { ?>
                        <p>
                            <?php echo $site_text; ?>
                        </p>
                    <?php } ?>

                        <?php if(!empty($app_link)) { ?>

                        <div class="buttonapp-store left"><a href="<?php echo $app_link; ?>"></a></div><!--/buttonapp-store-->

                            <?php } else { ?>

                        <?php  if($newsletter_type == 'Sendloop'){ ?>
                            <div  class="form-header left" >
          

                                <form action="http://<?php echo $sendloop_username ?>.sendloop.com/subscribe.php" method="post">
                                    <input class="input-header"  type="text" name="FormValue_Fields[EmailAddress]" value="" id="FormValue_EmailAddress" class="newsletter_email input-newsletter" src="style/img/menu-contact.png"/>
                                    <input type="submit" name="FormButton_Subscribe" value="" id="FormButton_Subscribe" class="newsletter_button submit-newsletter submit-header"/>
                                    <input type="hidden" name="FormValue_ListID" value="<?php echo $sendloop_list ?>" id="FormValue_ListID" />
                                    <input type="hidden" name="FormValue_Command" value="Subscriber.Add" id="FormValue_Command" />
                                </form>
                            </div><!--/form-header-->

                    <?php }elseif($newsletter_type == 'Mailchimp'){ ?>
                                <?php get_template_part('script/mailchimp/mailchimp')?>
                    <?php } ?>
                <?php } ?><!-- closes applink -->




                </div><!--/text-header-->

                <div class="slider-phone right">
                    <div class="bg-phone-white left"></div><!--/bg-phone-white-->
                    <div class="slider-wrapper theme-default">
                        <div id="slider" class="nivoSlider">

                    <?php

                        $args=array('post_status' => 'publish', 'post_type' => 'pt_slides',  'ignore_sticky_posts'=> 1, 'meta_key' => '_thumbnail_id');

                        //The Query
                        query_posts($args);

                        //The Loop
                        if ( have_posts() ) : while ( have_posts() ) : the_post();
                           the_post_thumbnail('slider');
                         endwhile; endif;
                     ?>


                        </div>
                    </div><!--/slider-wrapper-->
                </div><!--/slider-phone-->

            </div><!--/text-slider-header-->



            </div><!-- heighter -->
        </div><!--/wrapper-->
    </div><!--/header-->