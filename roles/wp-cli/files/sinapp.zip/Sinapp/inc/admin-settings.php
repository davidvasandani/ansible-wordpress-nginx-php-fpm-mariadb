<?php

$tabs = array(

        /*************************************************************/
        /************GENERAL OPTIONS*******************************/
        /*************************************************************/

    array(
        'pg' => array(
            'slug' => 'theme-settings',
            'menu_title' => 'Theme Settings',
            'page_title' => 'Theme Settings'
        ),
        'id' => 'general',
        'name' => 'General Options',

        'fields' => array(

           array(
                'id' => 'header_logo',
                'name' => 'header_logo',
                'type' => 'file',
                'value' => get_template_directory_uri()."/style/img/logo.png",
                'label' => 'Header Logo',
                'desc' => 'JPEG, GIF or PNG image, 300x95px recommended, up to 500KB',
            ),

            array(
                'id' => 'favicon',
                'name' => 'favicon',
                'type' => 'file',
                'value' => get_template_directory_uri()."/style/img/favicon.ico",
                'label' => 'Favicon',
                'desc' => 'File format: ICO, dimenstions: 16x16',

            ),

            array(
                'id' => 'google_analytics',
                'name' => 'google_analytics',
                'type' => 'textarea',
                'value' => '',
                'label' => 'Google Analytics code',
                'desc' => '',
                'options' => array(
                    'rows' => '5',
                    'cols' => '80'
                )
            ),


            array(
                'id' => 'app_store',
                'name' => 'app_store',
                'type' => 'text',
                'value' => '',
                'label' => 'Available on AppStore date',
                'desc' => 'Set the date when it will be available on AppStore',
                'options' => array(
                    'size' => '100'
                )
            ),

            array(
                'id' => 'app_link',
                'name' => 'app_link',
                'type' => 'text',
                'value' => '',
                'label' => 'Application link',
                'desc' => 'Set link where aplication is stored',
                'options' => array(
                    'size' => '100'
                )
            ),

            array(
                'id' => 'text_heading',
                'name' => 'text_heading',
                'type' => 'text',
                'value' => '',
                'label' => 'Headline Text',
                'desc' => 'Set headline text',
                'options' => array(
                    'size' => '100'
                )
            ),

            array(
                'id' => 'site_text',
                'name' => 'site_text',
                'type' => 'text',
                'value' => '',
                'label' => 'Main Header Text',
                'desc' => 'Set main text',
                'options' => array(
                    'size' => '100'
                )
            ),

            array(
                'id' => 'twitter',
                'name' => 'twitter',
                'type' => 'text',
                'value' => '',
                'label' => 'Twitter',
                'desc' => 'Twitter Name',
                'options' => array(
                    'size' => '15'
                )
            ),

            array(
                'id' => 'copyright_text',
                'name' => 'copyright_text',
                'type' => 'text',
                'value' => '',
                'label' => 'Copyright Text',
                'desc' => 'Write your copyright text',
                'options' => array(
                    'size' => '100'
                )
            ),

        ),

    ),




    //NEWSLETTER
    array(
        'pg' => array(
            'slug' => 'theme-settings',
            'menu_title' => 'Theme Settings',
            'page_title' => 'Theme Settings'
        ),
        'id' => 'newsletter',
        'name' => __('Newsletter', 'Wp Hotel'),
        'fields' => array(

            array(
                'id' => 'newsletter_service',
                'name' => 'newsletter_service',
                'type' => 'radio',
                'value' => array(
                    'Mailchimp',
                    'Sendloop',
                    'None',
                ),
                'caption' => array(
                    'Mailchimp',
                    'Sendloop',
                    'None',
                ),
                'label' => __('Newsletter Service', 'Wp Hotel'),
                'desc' => __('Use <a href="http://sendloop.com/">Sendloop</a> as your newsletter manager or use <a href="http://mailchimp.com/">Mailchimp</a> as your newsletter manager.', 'Wp Hotel'),
            ),
            array(
                'id' => 'mailchimp_api_key',
                'name' => 'mailchimp_api_key',
                'type' => 'text',
                'value' => '',
                'label' => __('Mailchimp API Key', 'Wp Hotel'),
                'desc' =>__('Grab and insert an API Key from <a href="http://admin.mailchimp.com/account/api/">here</a>', 'Wp Hotel'),
                'options' => array(
                    'size' => '100'
                )
            ),
            array(
                'id' => 'mailchimp_api_list',
                'name' => 'mailchimp_api_list',
                'type' => 'text',
                'value' => '',
                'label' => __('Mailchimp API List', 'Wp Hotel'),
                'desc' => __('Grab your Lists Unique Id by going to <a href="http://admin.mailchimp.com/lists/">here</a>. Click the "settings" link for the list - the Unique Id is at the bottom of that page.', 'Wp Hotel'),
                'options' => array(
                    'size' => '100'
                )
            ),
            array(
                'id' => 'sendloop_username',
                'name' => 'sendloop_username',
                'type' => 'text',
                'value' => '',
                'label' => __('Sendloop Username', 'Wp Hotel'),
                'desc' => __('Insert your Sendloop username. It can be fount when you log in into your Sendloop account it looks like <strong>XXXXX</strong>.sendloop.com', 'Wp Hotel'),
                'options' => array(
                    'size' => '100'
                )
            ),

            array(
                'id' => 'sendloop_list_id',
                'name' => 'sendloop_list_id',
                'type' => 'text',
                'value' => '',
                'label' => __('Sendloop List ID', 'Wp Hotel'),
                'desc' => __('Insert your Sandloop List Id. It can be found at Subscriber Lists-><strong>Your List</strong>->Edit List Settings', 'Wp Hotel'),
                'options' => array(
                    'size' => '100'
                )
            ),
            array(
                'id' => 'box_1_hr',
                'name' => 'box_1_hr',
                'type' => 'hr',
                'options' => array(
                    'width' => '100%',
                    'color' => '#DFDFDF'
                )
            ),


        ),
    ),


    //FONTS
    array(
        'pg' => array(
            'slug' => 'theme-settings',
            'menu_title' => 'Theme Settings',
            'page_title' => 'Theme Settings'
        ),
        'id' => 'fonts',
        'name' => __('Fonts', 'Sinapp'),
        'fields' => array(


            array(
                'id' => 'header_text_font',
                'name' => 'header_text_font',
                'type' => 'select',
                'value' => '',
                'label' => __('Header Font', 'Sinapp'),
                'desc' =>__('Choose your header font', 'Sinapp'),
                'options' => array(
                    'size' => '100'
                ),
                  'value' => array(
                    'Helvetica',
                    'Georgia',
                    'DosisMedium',
                    'GoodDogRegular',
                    'NeoRetroDrawRegular',
                    'ChunkFiveRegular',
                    'SansationRegular',
                    'OpenSansRegular',
                    'MuseoSlab500Regular',
                    'OpenSansRegular',
                    'Lobster13Regular'

                ),

                'caption' => array(
                    __('Helvetica','Sinapp'),
                    __('Georgia','Sinapp'),
                    __('Dosis','Sinapp'),
                    __('GoodDog','Sinapp'),
                    __('NeoRetro','Sinapp'),
                    __('ChunkFive','Sinapp'),
                    __('Sansation','Sinapp'),
                    __('OpenSans','Sinapp'),
                    __('MuseoSlab','Sinapp'),
                    __('OpenSans','Sinapp'),
                    __('Lobster','Sinapp'),

                ),
            ),


            array(
                'id' => 'paragraph_font',
                'name' => 'paragraph_font',
                'type' => 'select',
                'value' => '',
                'label' => __('Header Description Font', 'Sinapp'),
                'desc' =>__('Choose your header description font', 'Sinapp'),
                'options' => array(
                    'size' => '100'
                ),
                  'value' => array(
                    'Helvetica',
                    'Georgia',
                    'DosisMedium',
                    'GoodDogRegular',
                    'NeoRetroDrawRegular',
                    'ChunkFiveRegular',
                    'SansationRegular',
                    'OpenSansRegular',
                    'MuseoSlab500Regular',
                    'OpenSansRegular',
                    'Lobster13Regular'

                ),

                'caption' => array(
                    __('Helvetica','Sinapp'),
                    __('Georgia','Sinapp'),
                    __('Dosis','Sinapp'),
                    __('GoodDog','Sinapp'),
                    __('NeoRetro','Sinapp'),
                    __('ChunkFive','Sinapp'),
                    __('Sansation','Sinapp'),
                    __('OpenSans','Sinapp'),
                    __('MuseoSlab','Sinapp'),
                    __('OpenSans','Sinapp'),
                    __('Lobster','Sinapp'),

                ),
            ),

            array(
                'id' => 'headings_font',
                'name' => 'headings_font',
                'type' => 'select',
                'value' => '',
                'label' => __('Headings Font', 'Sinapp'),
                'desc' =>__('Choose your heading font', 'Sinapp'),
                'options' => array(
                    'size' => '100'
                ),
                  'value' => array(
                    'Helvetica',
                    'Georgia',
                    'DosisMedium',
                    'GoodDogRegular',
                    'NeoRetroDrawRegular',
                    'ChunkFiveRegular',
                    'SansationRegular',
                    'OpenSansRegular',
                    'MuseoSlab500Regular',
                    'OpenSansRegular',
                    'Lobster13Regular'

                ),

                'caption' => array(
                    __('Helvetica','Sinapp'),
                    __('Georgia','Sinapp'),
                    __('Dosis','Sinapp'),
                    __('GoodDog','Sinapp'),
                    __('NeoRetro','Sinapp'),
                    __('ChunkFive','Sinapp'),
                    __('Sansation','Sinapp'),
                    __('OpenSans','Sinapp'),
                    __('MuseoSlab','Sinapp'),
                    __('OpenSans','Sinapp'),
                    __('Lobster','Sinapp'),

                ),
            ),


            array(
                'id' => 'content_paragraph_font',
                'name' => 'content_paragraph_font',
                'type' => 'select',
                'value' => '',
                'label' => __('Content Text Font', 'Sinapp'),
                'desc' =>__('Choose your content text font', 'Sinapp'),
                'options' => array(
                    'size' => '100'
                ),
                  'value' => array(
                    'Helvetica',
                    'Georgia',
                    'DosisMedium',
                    'GoodDogRegular',
                    'NeoRetroDrawRegular',
                    'ChunkFiveRegular',
                    'SansationRegular',
                    'OpenSansRegular',
                    'MuseoSlab500Regular',
                    'OpenSansRegular',
                    'Lobster13Regular'

                ),

                'caption' => array(
                    __('Helvetica','Sinapp'),
                    __('Georgia','Sinapp'),
                    __('Dosis','Sinapp'),
                    __('GoodDog','Sinapp'),
                    __('NeoRetro','Sinapp'),
                    __('ChunkFive','Sinapp'),
                    __('Sansation','Sinapp'),
                    __('OpenSans','Sinapp'),
                    __('MuseoSlab','Sinapp'),
                    __('OpenSans','Sinapp'),
                    __('Lobster','Sinapp'),

                ),
            ),


    ),
),

    //Colors
    array(
        'pg' => array(
            'slug' => 'theme-settings',
            'menu_title' => 'Theme Settings',
            'page_title' => 'Theme Settings'
        ),
        'id' => 'colors',
        'name' => __('Colors and Backgrounds', 'Sinapp'),
        'fields' => array(


            array(
                'id' => 'phone_color',
                'name' => 'phone_color',
                'type' => 'select',
                'value' => '',
                'label' => __('Phone Color', 'Sinapp'),
                'desc' =>__('Choose your phone slider color', 'Sinapp'),

                'value' => array(
                    'black',
                    'white',
                ),

                'caption' => array(
                    __('Black','Sinapp'),
                    __('White','Sinapp'),
                ),

              ),

            array(
                'id' => 'header_text_color',
                'name' => 'header_text_color',
                'type' => 'colorpicker',
                'value' => 'fff',
                'label' => __('Header Font color', 'Sinapp'),
                'desc' =>__('Choose your header font color', 'Sinapp'),
              ),

            array(
                'id' => 'heading_paragraph_text_color',
                'name' => 'heading_paragraph_text_color',
                'type' => 'colorpicker',
                'value' => 'fff',
                'label' => __('Header Description Font Color', 'Sinapp'),
                'desc' =>__('Choose your description font color in header', 'Sinapp'),
              ),

            array(
                'id' => 'heading_text_color',
                'name' => 'heading_text_color',
                'type' => 'colorpicker',
                'value' => '0f0f0f',
                'label' => __('Headings Font color', 'Sinapp'),
                'desc' =>__('Choose your heading font color', 'Sinapp'),
              ),



            array(
                'id' => 'paragraph_text_color',
                'name' => 'paragraph_text_color',
                'type' => 'colorpicker',
                'value' => '666',
                'label' => __('Paragraph Font Color', 'Sinapp'),
                'desc' =>__('Choose your paragraph font color', 'Sinapp'),
              ),

            array(
                'id' => 'border_color',
                'name' => 'border_color',
                'type' => 'colorpicker',
                'value' => '000',
                'label' => __('Share Bar Border Color', 'Sinapp'),
                'desc' =>__('Set border color for share bar', 'Sinapp'),
              ),

            array(
                'id' => 'links_color',
                'name' => 'links_color',
                'type' => 'colorpicker',
                'value' => '000',
                'label' => __('Links Color', 'Sinapp'),
                'desc' =>__('Set links colors', 'Sinapp'),
              ),

            array(
                'id' => 'share_buttons_background',
                'name' => 'share_buttons_background',
                'type' => 'colorpicker',
                'value' => 'fff',
                'label' => __('Share Bar Background Color', 'Sinapp'),
                'desc' =>__('Set background color for share bar', 'Sinapp'),
              ),

            array(
                'id' => 'content_background',
                'name' => 'content_background',
                'type' => 'colorpicker',
                'value' => 'e9e9e9',
                'label' => __('Content Background Color', 'Sinapp'),
                'desc' =>__('Set background color for content', 'Sinapp'),
              ),

            array(
                'id' => 'twitter_back',
                'name' => 'twitter_back',
                'type' => 'colorpicker',
                'value' => '000',
                'label' => __('Twitter Background Color', 'Sinapp'),
                'desc' =>__('Set background color for twitter', 'Sinapp'),
              ),

            array(
                'id' => 'footer_back',
                'name' => 'footer_back',
                'type' => 'colorpicker',
                'value' => '666',
                'label' => __('Copyright Background Color', 'Sinapp'),
                'desc' =>__('Set background color for footer', 'Sinapp'),
              ),

            array(
                'id' => 'twitter_color',
                'name' => 'twitter_color',
                'type' => 'colorpicker',
                'value' => 'f6f6f5',
                'label' => __('Twitter Font Color', 'Sinapp'),
                'desc' =>__('Set Twitter font color', 'Sinapp'),
              ),

            array(
                'id' => 'button_test',
                'name' => 'button_test',
                'type' => 'button',
                'value' => __('Reset Colors', 'booker'),
                'label' => __('Reset Colors', 'booker'),
                'desc' => __('Reset Theme to default colors', 'booker'),
            ),
        ),
    ),
);
?>