<?php
             require( '../../../../wp-load.php' );

            $theme = wp_get_theme();


            update_option($theme->name.'_colors_header_text_color', 'fff');
            update_option($theme->name.'_colors_heading_paragraph_text_color', 'fff');
            update_option($theme->name.'_colors_heading_text_color', '0f0f0f');
            update_option($theme->name.'_colors_paragraph_text_color', '666666');
            update_option($theme->name.'_colors_links_color', 'fff');
            update_option($theme->name.'_colors_share_buttons_background', 'fff');
            update_option($theme->name.'_colors_content_background', 'e9e9e9');
            update_option($theme->name.'_colors_twitter_back', '000000');
            update_option($theme->name.'_colors_footer_back', '666');
            update_option($theme->name.'_colors_twitter_color', 'f6f6f5');

?>