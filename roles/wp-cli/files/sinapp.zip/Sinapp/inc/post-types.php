<?php

add_action( 'init', 'post_types_adding' );

function post_types_adding() {

        /*************************************************************/
        /************PORTFOLIO POST TYPE***************************/
        /*************************************************************/

  $labels = array(
    'name' => __('Slider', 'Sinapp'),
    'singular_name' => __('Slider', 'Sinapp'),
    'add_new' => __('Add New Slide', 'Sinapp'),
    'add_new_item' => __('Add New Slide', 'Sinapp'),
    'edit_item' => __('Edit Slide', 'Sinapp'),
    'new_item' => __('New Slide', 'Sinapp'),
    'all_items' => __('All Slides', 'Sinapp'),
    'view_item' => __('View this Slide', 'Sinapp'),
    'search_items' => __('Search Slides', 'Sinapp'),
    'not_found' =>  __('No Slides', 'Sinapp'),
    'not_found_in_trash' => __('No Slides in Trash', 'inkland'),
    'parent_item_colon' => '',
    'menu_name' => __('Slider', 'Sinapp'),

  );
  $args = array(
    'exclude_from_search' => false,
    'labels' => $labels,
    'public' => true,
    'publicly_queryable' => true,
    'show_ui' => true,
    'show_in_menu' => true,
    'query_var' => true,
    'rewrite' => array('slug' => 'slides'),
    'capability_type' => 'post',
    'has_archive' => true,
    'hierarchical' => false,
    'menu_position' => 100,
    'supports' => array('title',  'thumbnail' ),
);
  register_post_type('pt_slides',$args);

  flush_rewrite_rules();

} ?>