<?php
             require( '../../../../wp-load.php' );

            update_option('colors_header_background', 'F8F8F8');
            update_option('colors_body_background', 'F8F8F8');
            update_option('colors_middle_background', 'FFF');
            update_option('colors_footer_background', 'EBEBEB');
            update_option('colors_body_font_color', '5A5A5A');
            update_option('colors_headline_font_color', '353535');
            update_option('colors_links_color', '353535');
            update_option('colors_links_hover', 'DB5735');
            update_option('colors_buttons_lines_color', 'DB5735');
            update_option('colors_boxes_background', 'FFF');
            update_option('colors_border_color', 'DFDFDF');
            update_option('colors_button_text', 'FFF');

?>