<?php get_header();
$prefix = 'tk_';
$sidebar_position = get_post_meta(get_option('id_blog_page'), $prefix.'sidebar_position', true);
$blog_title = get_option('title_blog_page');
?>


    <!------ CONTENT ------>
    <div class="content left">


        <div class="bg-white left">
            <div class="wrapper">
                <div class="title-on-page left">
                    <div class="point-border-title left"><h5><?php echo $blog_title?></h5></div><!--/point-border-title-->
                </div><!--/title-on-page-->
            </div><!--/wrapper-->
            <div class="border-bottom-slider left"></div>
        </div><!--/bg-white-->



        <div class="wrapper">

            <?php tk_get_left_sidebar($sidebar_position, 'Blog')?>

            <div class="blog-page-content blog-left">



                <!------ BLOG-POST ------>
                <div class="blog-single-one left">
                    <div class="blog-single-images-title left">
                        <?php if(has_post_thumbnail()){?>
                        <div class="post-single-images left">
                                    <a href="<?php echo wp_get_attachment_url( get_post_thumbnail_id() )?>" class="pirobox " title="<?php the_title(); ?>" rel="single">
                                        <?php the_post_thumbnail('single'); ?>
                                    </a>
                        </div><!--/post-images-->
                        <?php }?>
                        <div class="blog-single-title-box left"><span><?php the_title() ?></span></div>
                    </div><!--/blog-single-images-title-->
                    <div class="post-single-date-content right">
                        <ul>
                            <li><span><?php _e('Posted:', 'tint')?></span></li>
                            <li><?php echo get_the_date()?></li>
                        </ul>

                        <ul>
                            <li><span><?php _e("Categories:", 'tint')?></span></li>
                            <li><?php echo get_the_category_list( '&nbsp; &nbsp;|&nbsp; &nbsp;', $post->ID ); ?></li>
                        </ul>
                        <?php $single_post_type = get_post_type($post->ID); if($single_post_type !== 'pt_slides'){?>
                            <ul style="margin-top: 19px;">
                                <li><span><?php _e("Comments:", 'tint')?></span><p><?php comments_number( '0', '1', '%' ); ?></p></li>
                            </ul>
                        <?php }?>
                    </div><!--/post-single-date-->
                    <div class="post-single-text left">
                        <p>
            <div class="blog-page-content left" style="margin-top: 0px">
                <div class="shortcodes left">
                        <?php
                            wp_reset_query();
                            if ( have_posts() ) : while ( have_posts() ) : the_post();
                                    the_content();
                                endwhile;
                            else:
                            endif;
                            wp_reset_query();
                            ?>

                        </div><!--/post-single-text-->
                    </div><!--/post-single-text-->
                </div><!--/content-one-->

                <?php
                $show_author = get_option('general_post_author');
                        if($show_author[0] == 'yes'){
                ?>

                                <div class="bg-single-title left"><h6><?php _e("About Autor:", 'tint')?></h6></div>
                                <div class="sign-up-home-content blog-single-user-content left">
                                    <div class="border-color left"></div>
                                    <div class="user-blog-single left">
                                        <div class="about-home-content left">
                                            <div class="about-home-images left"><a href="<?php echo get_the_author_meta('user_url')?>"><?php echo get_avatar(get_the_author_meta('ID'), '68', get_template_directory_uri().'/style/img/autor.jpg')?></a></div><!--/about-home-images-->
                                            <div class="about-home-text user-blog-single-text right">
                                                <a href="<?php echo get_the_author_meta('user_url')?>"><?php echo get_the_author_meta('display_name')?></a>
                                                <span><?php echo get_the_author_meta('description')?></span>
                                            </div><!--/user-blog-single-text-->
                                        </div><!--/about-home-content-->
                                    </div><!--/user-blog-single-->
                                </div><!--/sign-up-home-content-->
                <?php }?>


                <?php if ( comments_open() ) : ?>

                    <?php comments_template(); // Get wp-comments.php template ?>
                    
                <?php endif; ?>

                    </div><!--/blog-page-content-->
                </div><!--/bg-content-red-tape-->


            <?php tk_get_right_sidebar($sidebar_position, 'Blog')?>


        </div><!--/content-->
    </div><!--/content-->
<div class="bg-down-container left"></div>


<?php get_footer(); ?>