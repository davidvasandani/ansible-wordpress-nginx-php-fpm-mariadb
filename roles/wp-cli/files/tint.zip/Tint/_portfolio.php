<?php
/*

Template Name: Portfolio

*/
get_header();
?>
    <!------ CONTENT ------>
    <div class="content left">


        <div class="bg-white left">
            <div class="wrapper">
                <div class="title-on-page left">
                    <div class="point-border-title left"><h5><?php the_title()?></h5></div><!--/point-border-title-->
                </div><!--/title-on-page-->
            </div><!--/wrapper-->
            <div class="border-bottom-slider left"></div>
        </div><!--/bg-white-->



        <div class="wrapper">

                            <?php
                              global $wpdb;
                              $post_type_ids = $wpdb->get_col("SELECT ID FROM $wpdb->posts WHERE post_type = 'pt_portfolio' AND post_status = 'publish'");
                              if($post_type_ids){
                                $post_type_cats = wp_get_object_terms( $post_type_ids, 'category',array('fields' => 'ids') );
                                if($post_type_cats){
                                  $post_type_cats = array_unique($post_type_cats);
                                  $allcat = implode(',',$post_type_cats);
                                }
                              }
                              $include_category = null;
                            ?>

            <div class="page-portfolio-categories left">
                <div class="bg-portfolio-categories left">
                    <div class="portfolio-categories left">
                        <ul>
                            <li class="paragraphp cat_cell_active cat_cell" rev="<?php echo $allcat?>"><a href="#">All</a></li>
                          <?php
                             foreach ($post_type_cats as $category_list) {
                                $cat = 	$category_list.",";
                                $include_category = $include_category.$cat;
                                $cat_name = get_cat_name($category_list)
                            ?>
                            <li rev="<?php echo $category_list?>" class="cat_cell"><a href="#"><?php echo $cat_name?></a></li>
                            <?php } ?>
                        </ul>
                    </div><!--/portfolio-categories-->
                </div><!--/bg-portfolio-categories-->
            </div><!--/page-portfolio-categories-->

            
            <div class="portfolio-content left">
                    
                        <script type="text/javascript">
                            $(document).ready(function(){
                                jQuery('.cat_cell_active').click();
                            });
                        </script>

                        <script type="text/javascript">
                            $('.cat_cell').live('click',
                            function () {
                                var id = $(this).attr('rev');
                                jQuery('.ajax_holder').animate({opacity:0},500,function(){
                                    jQuery('.portfolio-loader').show().animate({opacity:0},0).animate({opacity:1},500,function(){
                                        $('.ajax_holder').empty();
                                        var randomnumber=Math.floor(Math.random()*100000000);
                                        var postAjaxURL = "<?php echo get_template_directory_uri() ?>/_portfolioajax.php?id="+id;

                                        $('.ajax_holder').load(postAjaxURL, {rand: randomnumber},function(){
                                            jQuery('.portfolio-loader').animate({opacity:0},500).hide();
                                            jQuery('.ajax_holder').animate({opacity:1},500);
                                        });
                                    });
                                });
                                return false;
                            });
                        </script>

                                <div class="portfolio-loader"></div> 
                                
				<div class="ajax_holder"></div><!--AJAX Holder-->
  
        </div> <!--close left_content -->

    </div> <!---->

</div><!--front-info-box-->

<?php get_footer(); ?>



