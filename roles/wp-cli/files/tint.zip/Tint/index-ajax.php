<?php
//loading wordpress functions
require( '../../../wp-load.php' );
    $post_type = $_GET['type'];
    if($post_type == 1){
            $item_counter = 1;
            $args=array('post_type' => 'post', 'post_status' => 'publish', 'ignore_sticky_posts'=> 1,'posts_per_page'=> 2);
               query_posts($args);
                //The Loop
                if ( have_posts() ) : while ( have_posts() ) : the_post();?>

                        <div class="whats-new-portfolio-one left" <?php if ($item_counter == 1){echo 'style="margin-left: 0;"';}?>>
                            <div class="whats-new-portfolio-images left">
                                    <a href="<?php echo wp_get_attachment_url( get_post_thumbnail_id() )?>" class="pirobox " title="<?php the_title(); ?>" rel="single">
                                        <?php the_post_thumbnail('home_portfolio'); ?>
                                    </a>
                            </div><!--/whats-new-portfolio-images-->
                            <div class="whats-new-portfolio-text-content left">
                                <div class="whats-new-portfolio-title"><a href="<?php the_permalink()?>"><?php the_title() ?></a></div><!--/whats-new-portfolio-title-->
                                <div class="whats-new-portfolio-data"><?php echo get_the_date()?></div><!--/whats-new-portfolio-data-->
                                <div class="whats-new-portfolio-text"><?php the_excerpt()?></div><!--/whats-new-portfolio-text-->
                            </div><!--/whats-new-portfolio-text-content-->
                        </div><!--/whats-new-portfolio-one-->

                 <?php
                     $item_counter++;
                     endwhile;
                     endif;
                 ?>
<?php
    }else{
            $item_counter = 1;
            $args=array('post_type' => 'pt_portfolio', 'post_status' => 'publish', 'ignore_sticky_posts'=> 1,'posts_per_page'=> 3);
               query_posts($args);
                //The Loop
                if ( have_posts() ) : while ( have_posts() ) : the_post();?>

                        <div class="whats-new-one left"  <?php if ($item_counter == 1){echo 'style="margin-left: 0;"';}?>>
                            <div class="whats-new-images left">
                                    <a href="<?php echo wp_get_attachment_url( get_post_thumbnail_id() )?>" class="pirobox " title="<?php the_title(); ?>" rel="single">
                                        <?php the_post_thumbnail('portfolio'); ?>
                                    </a>
                            </div><!--/whats-new-images-->
                            <div class="whats-new-text-content left">
                                <div class="whats-new-title"><a href="<?php the_permalink()?>"><?php the_title() ?></a></div><!--/whats-new-title-->
                                <div class="whats-new-data"><?php echo get_the_category_list( '&nbsp; &nbsp;|&nbsp; &nbsp;', $post->ID ); ?></div><!--/whats-new-data-->
                            </div><!--/whats-new-text-content-->
                        </div><!--/whats-new-one-->

                 <?php
                     $item_counter++;
                     endwhile;
                     endif;
    }
?>
        <?php
            $body_font = get_option('colors_body_font_color');
            $links_color = get_option('colors_links_color');
            $links_hover = get_option('colors_links_hover');
        ?>
                      <script type="text/javascript">
                        jQuery(document).ready(function(){

                                jQuery(".whats-new-title a").hover(function() {
                                        jQuery(this).animate({color: "#<?php echo $links_hover; ?>"},{duration:200,queue:false}, 'easeOutSine');
                                },function() {
                                        jQuery(this).animate({color: "#<?php echo $links_color; ?>"},{duration:300,queue:false}, 'easeOutSine');
                                });

                                jQuery(".whats-new-data a").hover(function() {
                                        jQuery(this).animate({color: "#<?php echo $links_hover; ?>"},{duration:200,queue:false}, 'easeOutSine');
                                },function() {
                                        jQuery(this).animate({color: "#<?php echo $body_font; ?>"},{duration:300,queue:false}, 'easeOutSine');
                                });

                                jQuery(".whats-new-portfolio-title a").hover(function() {
                                        jQuery(this).animate({color: "#<?php echo $links_hover; ?>"},{duration:200,queue:false}, 'easeOutSine');
                                },function() {
                                        jQuery(this).animate({color: "#<?php echo $links_color; ?>"},{duration:300,queue:false}, 'easeOutSine');
                                });


                                $('.piro_overlay,.pirobox_content').remove();
                                $().piroBox({
                                    my_speed: 300,
                                    bg_alpha:0.5,
                                    radius: 4,
                                    scrollImage : false,
                                    slideShow : 'true',
                                    slideSpeed : 3,
                                    pirobox_next : 'piro_next',
                                    pirobox_prev : 'piro_prev',
                                    close_all : '.piro_close'
                                });

                                jQuery('img','.pirobox').hover(function(){
                                    jQuery(this).stop().animate({
                                        opacity:0.4
                                    },500);
                                },function(){
                                    jQuery(this).stop().animate({
                                        opacity:1
                                    },300);
                                });

                        })
                        </script>