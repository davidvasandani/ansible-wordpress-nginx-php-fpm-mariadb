<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html <?php language_attributes(); ?>
<head profile="http://gmpg.org/xfn/11">

	<title><?php bloginfo('name'); ?> <?php wp_title(); ?></title>

	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />	
	<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats please -->

	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

        <link rel="stylesheet" media="screen" href="<?php echo get_template_directory_uri() . "/script/menu/superfish.css"; ?>" type="text/css"/>
        <link rel="stylesheet" media="screen" href="<?php echo get_template_directory_uri() . "/script/pirobox/css/demo5/style.css"; ?>" type="text/css"/>
        <link rel="stylesheet" media="screen" href="<?php echo get_template_directory_uri() . "/script/nivoSlider/nivo-slider.css"; ?>" />
        <link rel="stylesheet" media="screen" href="<?php echo get_template_directory_uri() . "/script/anythingslider/css/anythingslider.css"; ?>" type="text/css"/>


<?php

        /*************************************************************/
        /*Test user agent and load css for it***************************/
        /*************************************************************/


        $ua = $_SERVER["HTTP_USER_AGENT"];

        // Macintosh
        $mac = strpos($ua, 'Macintosh') ? true : false;

        // Windows
        $win = strpos($ua, 'Windows') ? true : false;


        $browser = $_SERVER['HTTP_USER_AGENT'];

        if (strpos($browser, 'Safari')) {
            ?>
                <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/safari.css" type="text/css" />
            <?php
            if(!empty($win)) {
                if($win == 'Windows') { ?>
                    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/win-safari.css" type="text/css" />
                <?php
                }
            }
        }

        if (strpos($browser, 'MSIE 8.0')) {
            ?>
                <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/ie8.css" type="text/css" />
            <?php
        }

        if (strpos($browser, 'MSIE 9.0')) {
            ?>
        <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/ie9.css" type="text/css" />
            <?php
        }

        if (strpos($browser, 'Chrome')) {
            ?>
                <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/chrome.css" type="text/css" />
            <?php
            if(!empty($win)) {
                if($win == 'Windows') { ?>
                    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/win-chrome.css" type="text/css" />
                <?php
                }
            }
        }

        if (strpos($browser, 'pera')) {
            ?>
                <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/opera.css" type="text/css" />
            <?php
            if(!empty($win)) {
                if($win == Windows) { ?>
                    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style/win-opera.css" type="text/css" />
                <?php
                }
            }
        }
?>


        
        <?php

        /*************************************************************/
        /************LOAD SCRIPTS***********************************/
        /*************************************************************/

            wp_deregister_script('jquery');
            wp_register_script('jquery', get_template_directory_uri().'/script/jquery/jquery-1.7.2.min.js');
            wp_enqueue_script('jquery');
            wp_enqueue_script('superfish', get_template_directory_uri().'/script/menu/superfish.js' );
            wp_enqueue_script('ajaxpager', get_template_directory_uri() . '/script/quickpager/quickpager.jquery.js');
            wp_enqueue_script('my-commons', get_template_directory_uri().'/script/common.js' );
            wp_enqueue_script('pirobox', get_template_directory_uri().'/script/pirobox/js/pirobox.js' );
            wp_enqueue_script('contact', get_template_directory_uri().'/script/contact/contact.js' );
            wp_enqueue_script('easing', get_template_directory_uri().'/script/easing/jquery.easing.1.3.js' );
            wp_enqueue_script('elastic', get_template_directory_uri().'/script/elastic/jquery.elastic.source.js' );
            wp_enqueue_script('anything', get_template_directory_uri().'/script/anythingslider/js/jquery.anythingslider.js' );
            wp_enqueue_script('nivoslider', get_template_directory_uri().'/script/nivoSlider/jquery.nivo.slider.pack.js' );
            wp_enqueue_script('animation', get_template_directory_uri().'/script/animate-colors/jquery.animate-colors.js' );
            wp_enqueue_script('flowplayer', get_template_directory_uri().'/script/flowplayer/flowplayer-3.2.6.min.js' );
            if ( is_singular() ) wp_enqueue_script( 'comment-reply' );
        ?>

        <?php $favicon = get_option('general_favicon'); if(empty($favicon)) { $favicon = get_template_directory_uri()."/style/img/favicon.ico"; }?>
        <link rel="shortcut icon" href="<?php echo $favicon;?>" />


        <?php
            $header_background = get_option('colors_header_background');
            $body_background = get_option('colors_body_background');
            $middle_background = get_option('colors_middle_background');
            $footer_background = get_option('colors_footer_background');
            $body_font = get_option('colors_body_font_color');
            $headlines_font = get_option('colors_headline_font_color');
            $links_color = get_option('colors_links_color');
            $links_hover = get_option('colors_links_hover');
            $buttons = get_option('colors_buttons_lines_color');
            $boxes = get_option('colors_boxes_background');
            $borders = get_option('colors_border_color');
            $button_text = get_option('colors_button_text');

        ?>

        <style type="text/css">

            /*BODY BACKGROUND COLOR*/
            body, .bg-single-title h6, .point-border-title h5 {
                background-color:#<?php echo $body_background; ?> !important;
            }


            /* HEADER BACKGROUND COLOR*/
            .header {
                background-color:#<?php echo $header_background; ?> !important;
            }

            /*MIDDLE BACKGROUND*/
            .bg-white, .title-on-page .point-border-title h5, .bg-call-action-home {
                background-color:#<?php echo $middle_background; ?> !important;
            }


            /*FOOTER BACKGROUND*/
            .footer {
                background-color:#<?php echo $footer_background; ?> !important;
            }

            /*TEXT COLORS*/
            .blog-page-content,
            .bg-widget-center span,
            .footer_box ul li,
            .footer-copy-text,
            .textwidget,
            .textwidget p,
            .post-single-text p,
            .post-text, .post-text p,
            .sidebar_widget_holder ul li,
            .post-date-content ul li,
            .whats-new-links-text {
                color:#<?php echo $body_font; ?> !important;
}

        
            .nav ul li a:hover {
                border-color: #<?php echo $links_hover ?> !important;
            }

            .current-menu-item a{
                border-color: #<?php echo $links_hover ?> !important;
            }

            /*BOXES COLORS*/
            .sidebar_widget_holder,
            .background-color, .blog-images-title,
            .blog-single-images-title,
            .sign-up-home-content,
            .page-portfolio-categories,
            .whats-new-one, .sgign-up-home-content,
            .sidebar_widget_holder h3,
            .portfolio-categories {
                        background-color:#<?php echo $boxes; ?> !important;
            }


            /*BUTTON COLORS*/
            .widget-tags-button, .form input.submit-button{
                        background-color:#<?php echo $buttons; ?> !important;
            }


            /*IMAGE BORDER*/
            .shortcodes img{
                        border: 1px solid #<?php echo $borders ?> !important;
            }


            /*HEADLINES COLORS*/
            .title-on-page .point-border-title h5,
            .blog-single-title-box span,
            .sidebar_widget_holder h3, .footer_box h2,
            .point-border-title h5 {
                    color:#<?php echo $headlines_font ?> !important;
            }

            .color-buttons a{
                color: #<?php echo $button_text ?> !important;
            }

            .color-buttons a:hover{
                color: #<?php echo $button_text ?> !important;
            }
            </style>

        
        <?php

         $g_analitics = stripslashes(get_option('general_google_analytics'));

         if( isset ($g_analitics) && $g_analitics != ''){
             echo $g_analitics;
         }

        ?>


<?php wp_head(); ?>

<script type="text/javascript">
            jQuery(document).ready(function(){
                // ANIMATE-COLOR
                    jQuery(".call-action-title a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".more-info a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".about-home-text a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".whats-new-links ul li a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".whats-new-links-text a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".whats-new-title a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".whats-new-portfolio-title a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".whats-new-data a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".footer-categories a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".footer_box .box-twitter-center a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".page-404-text-link a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".sidebar_widget_holder ul li a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".app_recent_title a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".sidebar_widget_holder tfoot a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".sidebar_widget_holder tbody a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".sidebar_widget_holder .menu-container ul li a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".blog-title-box a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".post-date-content ul li a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".post-single-date-content ul li a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $body_font ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });


                    jQuery(".nivo-caption a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });

                    jQuery(".text-slider-panel-text a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_color  ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });

                    jQuery(".textwidget a").hover(function() {
                            jQuery(this).animate({color: "#<?php echo $links_color ?>"},{duration:200,queue:false}, 'easeOutSine');
                    },function() {
                            jQuery(this).animate({color: "#<?php echo $links_hover  ?>"},{duration:300,queue:false}, 'easeOutSine');
                    });
                });
        </script>

</head>
<body <?php body_class(); ?>>
<?php if ( ! isset( $content_width ) ) $content_width = 980; ?>


<div id="container">

    <div class="header left">

        <div class="border-color left"></div>

    	<div class="wrapper">

            <!--LOGO-->
        <div class="logo left">
           <?php
                $logo = get_option('general_header_logo');
                if(empty($logo)) {
                $logo = get_template_directory_uri()."/style/img/logo.png";
             }?>

                <a href="<?php echo home_url(); ?>"><img src="<?php echo $logo; ?>" alt='logo' /></a>

        </div>

            <!--MENU-->
       <?php
        if ( function_exists('has_nav_menu') && has_nav_menu('primary') ) {
        $nav_menu = array('title_li'=> '', 'theme_location' => 'primary',   'menu_class'      => 'sf-menu',  'container_class' => 'nav right');
        wp_nav_menu($nav_menu);
        } else { ?>
        <div class="nav right">
            <ul class="sf-menu">
            <?php
             $pageargs = array(
                    'depth'        => 3,
                    'title_li'     => '',
                    'echo'         => 1,
                    'authors'      => '',				
                    'link_before'  => '',
                    'link_after'   => '',
                    'walker' => '' );
            wp_list_pages($pageargs);?>
            </ul>
        </div>
        <?php } ?>
            
        </div><!--/wrapper-->

        <div class="border-bottom-header left"></div>

    </div><!--/header-->