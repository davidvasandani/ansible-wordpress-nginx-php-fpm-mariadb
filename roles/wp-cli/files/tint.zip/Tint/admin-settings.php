<?php
$tabs = array(
        array(
            'menu_item' => 'First',
            'id' => 'homepage',
            'name' => 'Home',
            'fields' => array(
                array(
                    'id' => 'first',
                    'name' => 'first',
                    'type' => 'text',
                    'value' => '',
                    'label' => 'First Field',
                    'desc' => 'Description 1',
                ),
                array(
                    'id' => 'read',
                    'name' => 'read',
                    'type' => 'text',
                    'value' => 'This is readonly text',
                    'label' => 'Read Only',
                    'desc' => 'This text can\'t be changed',
                    'options' => array(
                        'readonly' => 'readonly=""'
                    )
                ),
                array(
                    'id' => 'hiddenField',
                    'name' => 'hiddenField',
                    'type' => 'hidden',
                    'value' => '',
                    'label' => '',
                    'desc' => ''
                ),
                array(
                    'id' => 'password',
                    'name' => 'password',
                    'type' => 'password',
                    'value' => 'somepass',
                    'label' => 'Secure Password',
                    'desc' => 'Your password goes here'
                ),
                array(
                    'id' => 'second',
                    'name' => 'second',
                    'type' => 'select',
                    'value' => array(
                        'first',
                        'second',
                        'third'
                    ),
                    'label' => 'Select Box',
                    'desc' => 'Description 2'
                ),
                array(
                    'id' => 'third',
                    'name' => 'third',
                    'type' => 'textarea',
                    'value' => '',
                    'label' => 'Nice Textarea',
                    'desc' => 'Textarea description',
                    'options' => array(
                        'rows' => '5',
                        'cols' => '80'
                    )
                ),
                array(
                    'id' => 'checkbox',
                    'name' => 'Checkbox',
                    'type' => 'checkbox',
                    'value' => array(
                        'first',
                        'second',
                        'third'
                    ),
                    'caption' => array(
                        'First caption',
                        'Second caption',
                        'Third caption'
                    ),
                    'label' => 'Checkbox fields',
                    'desc' => 'Checkbox additional description'
                ),
                array(
                    'id' => 'radio',
                    'name' => 'Radio',
                    'type' => 'radio',
                    'value' => array(
                        'first',
                        'second',
                        'third'
                    ),
                    'caption' => array(
                        'First caption',
                        'Second caption',
                        'Third caption'
                    ),
                    'label' => 'Radio Fields',
                    'desc' => 'Radio additional description',
                ),
                array(
                    'id' => 'testFile',
                    'name' => 'testFile',
                    'type' => 'file',
                    'value' => '',
                    'label' => 'Upload Image',
                    'desc' => '400x400px recommended, less than 500kb',
                ),
            ),
        ),
        array(
            'menu_item' => 'First',
            'id' => 'general',
            'name' => 'General',
            'fields' => array(
                array(
                    'id' => 'first',
                    'name' => 'first',
                    'type' => 'text',
                    'value' => '',
                    'label' => 'First Field',
                    'desc' => 'Description 1'
                ),
                array(
                    'id' => 'third',
                    'name' => 'third',
                    'type' => 'text',
                    'value' => '',
                    'label' => 'Third Field',
                    'desc' => 'Description 3'
                ),
            ),
        ),
        array(
            'menu_item' => 'Second',
            'id' => 'footer',
            'name' => 'Footer',
            'fields' => array(
                array(
                    'id' => 'third',
                    'name' => 'third',
                    'type' => 'textarea',
                    'value' => '',
                    'label' => 'Nice Textarea',
                    'desc' => 'Textarea description',
                    'options' => array(
                        'rows' => '5',
                        'cols' => '80'
                    )
                ),
            ),
        ),
        array(
            'menu_item' => 'Second',
            'id' => 'portfolio',
            'name' => 'Portfolio',
            'fields' => array(
                array(
                    'id' => 'image1',
                    'name' => 'image1',
                    'type' => 'file',
                    'value' => '',
                    'label' => 'Upload Image 1',
                    'desc' => '400x400px recommended, less than 500kb',
                ),
                array(
                    'id' => 'image2',
                    'name' => 'image2',
                    'type' => 'file',
                    'value' => '',
                    'label' => 'Upload Image 2',
                    'desc' => '400x400px recommended, less than 500kb',
                ),
                array(
                    'id' => 'image3',
                    'name' => 'image3',
                    'type' => 'file',
                    'value' => '',
                    'label' => 'Upload Image 3',
                    'desc' => '400x400px recommended, less than 500kb',
                ),
            ),
        ),
    );
?>
