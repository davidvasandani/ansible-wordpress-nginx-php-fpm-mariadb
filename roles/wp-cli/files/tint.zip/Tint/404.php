<?php

get_header(); ?>

    <div class="content left">


        <div class="bg-white left">
            <div class="wrapper">
                <div class="title-on-page left">
                    <div class="point-border-title left"><h5><?php _e("404 - error", 'tint')?></h5></div><!--/point-border-title-->
                </div><!--/title-on-page-->
            </div><!--/wrapper-->
            <div class="border-bottom-slider left"></div>
        </div><!--/bg-white-->

        <div class="wrapper">

            <div class="page-404-content left">
                <div class="page-404-text left">
                    <div class="bg-404-text left"><span><?php _e("Looks like the page you were looking for does not exist. Sorry about that.", 'tint')?></span></div>
                </div><!--/page-404-text-->
            </div><!--/page-404-content-->

            <div class="page-404-text-link left"><span><?php _e("Check the web address for typos, or go to", 'tint')?></span><a href="<?php echo home_url()?>"><?php _e("Home page", 'tint')?></a></div>

        </div><!--/wrapper-->
    </div><!--/content-->



<?php get_footer(); ?>