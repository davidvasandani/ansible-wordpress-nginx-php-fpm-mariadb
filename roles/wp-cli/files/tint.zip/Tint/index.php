<?php get_header();?>

    <!------ CONTENT ------>
    <div class="content left">

        <?php
        $slider_show = get_option('general_enable_slider');
        $slider_auto = get_option('general_auto_play');
        $slider_speed = get_option('general_slider_delay');
        $slider_animation_time = get_option('general_animation_time');
        if(empty($slider_speed)) {$slider_speed = "4000";}
        if(empty($slider_animation_time)) {$slider_animation_time = "1000";}

        if($slider_show[0] == 'yes') {
        ?>

        <div class="bg-white left">
            <div class="wrapper">
                <div class="slider-home left">
                    <ul id="slider2">
                      <?php

                      $args=array('post_type' => 'pt_slides' ,'post_status' => 'publish',  'posts_per_page' => 10);
                      query_posts($args);
                        if ( have_posts() ) : while ( have_posts() ) : the_post();

                        $video_link = get_post_meta($post->ID, 'tk_video_link', true);

                        if($video_link){?>
                            <li>
                                <div class="textSlide left">
                                    <div class="text-img-slider-panel left">
                                        <div class="text-slider-panel-text left"><?php the_content()?></div>
                                    </div>
                                <?php tk_video_player($video_link)?>
                                </div>
                            </li>
                        <?php } elseif(has_post_thumbnail()){?>
                        <li>
                            <a href="<?php echo the_permalink()?>" style="display: inline-block;width: 100%;height: 100%;"><?php the_post_thumbnail('slider'); ?></a>
                        </li>
                        <?php }else{?>
                            <li>
                                <div class="textSlide left">
                                        <?php the_content()?>
                                </div>
                            </li>
                      <?php }
                          endwhile;
                          endif;
                      ?>
                    </ul>
                </div><!--/slider-home-->
            </div><!--/wrapper-->
        </div><!--/bg-white-->


        <script type="text/javascript">
        jQuery(document).ready(function(){

            $('#slider2').anythingSlider({
            resizeContents      : false,
                    expand              : false,
                    startStopped        : false,
                    buildArrows         : false,
                    buildStartStop      : false,
                    delay               : <?php echo $slider_speed?>,
                    animationTime       : <?php echo $slider_animation_time?>,
                    easing              : "easeInOutExpo",
                    autoPlay            : <?php if ($slider_auto[0] == 'yes'){echo 'true';}else{echo 'false';}?>,
                    onSlideComplete : function(slider){
                    },
            onSlideBegin: function(e,slider) {
                    // keep the current navigation tab in view
                    slider.navWindow( slider.targetPage );
                }
            });

        })
        </script>


        <?php }

        /*************************************************************/
        /************FEATURE BOXES*********************************/
        /*************************************************************/

        ?>


        
        <div class="bg-call-action-home left"><div class="border-bottom-slider left" style="margin-top: 55px;"></div></div>
        
        <div class="wrapper">

        <?php
        $featured_show = get_option('featured_enable_featured_boxes');

        $featured_title_1 = get_option('featured_box_1_title');
        $featured_description_1 = get_option('featured_box_1_description');
        $featured_link_1 = get_option('featured_box_1_link');
        $featured_color_1 = get_option('featured_box_1_color');

        $featured_title_2 = get_option('featured_box_2_title');
        $featured_description_2 = get_option('featured_box_2_description');
        $featured_link_2 = get_option('featured_box_2_link');
        $featured_color_2 = get_option('featured_box_2_color');

        $featured_title_3 = get_option('featured_box_3_title');
        $featured_description_3 = get_option('featured_box_3_description');
        $featured_link_3 = get_option('featured_box_3_link');
        $featured_color_3 = get_option('featured_box_3_color');

        $featured_title_4 = get_option('featured_box_4_title');
        $featured_description_4 = get_option('featured_box_4_description');
        $featured_link_4 = get_option('featured_box_4_link');
        $featured_color_4 = get_option('featured_box_4_color');

        if($featured_show[0] == 'yes') {
        ?>
            
            <div class="call-action-home left">
                <div class="call-action-one left" style="background-color:<?php echo '#'.$featured_color_1?>!important">
                    <div class="call-action-title left"><span></span><a href="#"><?php echo stripslashes($featured_title_1);?></a></div><!--/call-action-title-->
                    <div class="call-action-text"><?php echo stripslashes($featured_description_1); ?></div><!--/call-action-text-->
                    <div class="more-info"><a href="<?php echo $featured_link_1?>"><?php _e('more info', 'tint')?></a></div><!--/call-action-text-->
                </div><!--/call-action-one-->

                <div class="call-action-one left" style="background-color:<?php echo '#'.$featured_color_2?>!important">
                    <div class="call-action-title left"><span></span><a href="#"><?php echo stripslashes($featured_title_2);?></a></div><!--/call-action-title-->
                    <div class="call-action-text"><?php echo stripslashes($featured_description_2);?></div><!--/call-action-text-->
                    <div class="more-info"><a href="<?php echo $featured_link_2?>"><?php _e('more info', 'tint')?></a></div><!--/call-action-text-->
                </div><!--/call-action-one-->

                <div class="call-action-one left" style="background-color:<?php echo '#'.$featured_color_3?>!important">
                    <div class="call-action-title left"><span></span><a href="#"><?php echo stripslashes($featured_title_3);?></a></div><!--/call-action-title-->
                    <div class="call-action-text"><?php echo stripslashes($featured_description_3);?></div><!--/call-action-text-->
                    <div class="more-info"><a href="<?php echo $featured_link_3?>"><?php _e('more info', 'tint')?></a></div><!--/call-action-text-->
                </div><!--/call-action-one-->

                <div class="call-action-one left" style="background-color:<?php echo '#'.$featured_color_4?>!important">
                    <div class="call-action-title left"><span></span><a href="#"><?php echo stripslashes($featured_title_4);?></a></div><!--/call-action-title-->
                    <div class="call-action-text"><?php echo stripslashes($featured_description_4);?></div><!--/call-action-text-->
                    <div class="more-info"><a href="<?php echo $featured_link_4?>"><?php _e('more info', 'tint')?></a></div><!--/call-action-text-->
                </div><!--/call-action-one-->

            </div><!--/call-action-home-->
            <div class="call-action-hom-border-down left"></div>

            <?php }?>

            <?php if($featured_show[0] !== 'yes'){?>
                <div style="margin-bottom:40px;display:inline-block"></div>
            <?php }?>

        <?php

        /*************************************************************/
        /************NEWS AND PORTFOLIO***************************/
        /*************************************************************/

        $whats_new_type = get_option('general_display_boxes');
        $whats_new_headline = get_option('general_headline_text');
        $whats_new_desc = get_option('general_description_text');

        if($whats_new_type == 'News and Portfolio') {
        ?>


            <div class="whats-new-home left" >
                <div class="point-border-title left"><h5><?php echo $whats_new_headline?></h5></div><!--/point-border-title-->
                <div class="whats-new-content left">
                    <div class="whats-new-links left">
                        <ul>
                            <li style="margin: 0;"></li>
                            <li rev="1" class="active"><img src="<?php echo get_template_directory_uri()?>/style/img/new-icon.png" alt="img" title="img" /><a href="#"><?php _e("news", 'tint')?></a></li>
                            <li rev="2"><img src="<?php echo get_template_directory_uri()?>/style/img/portfolio-icon.png" alt="img" title="img" /><a href="#"><?php _e("portfolio", 'tint')?></a></li>
                        </ul>
                        <?php $blog_id = get_option('id_blog_page'); ?>
                        <div class="whats-new-links-text left"><?php echo $whats_new_desc?></div><!--/whats-new-links-text-->
                    </div><!--/whats-new-links-->



                <!-- AJAX -->
                <script type="text/javascript">
                        //loads posts
                            $('.whats-new-links li').live('click',
                            function () {
                                 $('.whats-new-links li').removeClass('active');
                                  var url = $(this).addClass('active').attr('href');


                                var id = $(this).attr('rev');
                                jQuery('.whats-new-ajax').animate({opacity:0},500,function(){
                                    jQuery('.portfolio-loader').attr('style', 'display: block;');
                                        $('.whats-new-ajax').empty();

                                        var randomnumber=Math.floor(Math.random()*100000000);
                                        var postAjaxURL = "<?php echo get_template_directory_uri()?>/index-ajax.php?type="+id;


                                        $('.whats-new-ajax').load(postAjaxURL, {rand: randomnumber},function(){
                                            jQuery('.portfolio-loader').animate({opacity:0},500).hide();
                                            jQuery('.whats-new-ajax').animate({opacity:1},500);

                                          });
                                    });
                                return false;
                            });

                    </script>

                    <div class="whats-new-ajax right">
            <?php
            $item_counter = 1;
            $args=array('post_type' => 'post', 'post_status' => 'publish', 'ignore_sticky_posts'=> 1,'posts_per_page'=> 2);
               query_posts($args);
                //The Loop
                if ( have_posts() ) : while ( have_posts() ) : the_post();
                ?>

                        <div class="whats-new-portfolio-one left" <?php if ($item_counter == 1){echo 'style="margin-left: 0;"';}?>>
                            <div class="whats-new-portfolio-images left">
                                    <a href="<?php echo wp_get_attachment_url( get_post_thumbnail_id() )?>" class="pirobox " title="<?php the_title(); ?>" rel="single">
                                        <?php the_post_thumbnail('home_portfolio'); ?>
                                    </a>
                            </div><!--/whats-new-portfolio-images-->
                            <div class="whats-new-portfolio-text-content left">
                                <div class="whats-new-portfolio-title"><a href="<?php the_permalink()?>"><?php the_title() ?></a></div><!--/whats-new-portfolio-title-->
                                <div class="whats-new-portfolio-data"><?php echo get_the_date()?></div><!--/whats-new-portfolio-data-->
                                <div class="whats-new-portfolio-text"><?php the_excerpt()?></div><!--/whats-new-portfolio-text-->
                            </div><!--/whats-new-portfolio-text-content-->
                        </div><!--/whats-new-portfolio-one-->

                 <?php
                     $item_counter++;
                     endwhile;
                     endif;
                 ?>

                    </div><!--/whats-new-ajax-->

                </div><!--/whats-new-content-->
            </div><!--/whats-new-home-->

<?php }elseif($whats_new_type == 'News'){?>

            <div class="whats-new-home left" >
                <div class="point-border-title left"><h5><?php echo $whats_new_headline?></h5></div><!--/point-border-title-->
                <div class="whats-new-content left">
                    <div class="whats-new-links left">
                        <ul>
                            <li style="margin: 0;"></li>
                            <li rev="1" class="active"><img src="<?php echo get_template_directory_uri()?>/style/img/new-icon.png" alt="img" title="img" /><?php _e("news", 'tint')?></li>
                        </ul>
                        <div class="whats-new-links-text left"><?php echo $whats_new_desc?></div><!--/whats-new-links-text-->
                    </div><!--/whats-new-links-->
                    
                    <?php  $item_counter = 1;
                    $args=array('post_type' => 'post', 'post_status' => 'publish', 'ignore_sticky_posts'=> 1,'posts_per_page'=> 2);
                    query_posts($args);
                    //The Loop
                    if ( have_posts() ) : while ( have_posts() ) : the_post();?>

                        <div class="whats-new-portfolio-one left" <?php if ($item_counter == 1){echo 'style="margin-left: 0;"';}?>>
                            <div class="whats-new-portfolio-images left">
                                    <a href="<?php echo wp_get_attachment_url( get_post_thumbnail_id() )?>" class="pirobox " title="<?php the_title(); ?>" rel="single">
                                        <?php the_post_thumbnail('home_portfolio'); ?>
                                    </a>
                            </div><!--/whats-new-portfolio-images-->
                            <div class="whats-new-portfolio-text-content left">
                                <div class="whats-new-portfolio-title"><a href="<?php the_permalink()?>"><?php the_title() ?></a></div><!--/whats-new-portfolio-title-->
                                <div class="whats-new-portfolio-data"><?php echo get_the_date()?></div><!--/whats-new-portfolio-data-->
                                <div class="whats-new-portfolio-text"><?php the_excerpt()?></div><!--/whats-new-portfolio-text-->
                            </div><!--/whats-new-portfolio-text-content-->
                        </div><!--/whats-new-portfolio-one-->


                    <?php
                    $item_counter++;
                    endwhile;
                    endif;
                    ?>
                    
                </div><!--/whats-new-ajax-->

            </div><!--/whats-new-content-->
                    
<?php }elseif($whats_new_type == 'Portfolio'){?>

            <div class="whats-new-home left" >
                <div class="point-border-title left"><h5><?php echo $whats_new_headline?></h5></div><!--/point-border-title-->
                <div class="whats-new-content left">
                    <div class="whats-new-links left">
                        <ul>
                            <li style="margin: 0;"></li>
                            <li rev="2"><img src="<?php echo get_template_directory_uri()?>/style/img/portfolio-icon.png" alt="img" title="img" /><?php _e("portfolio", 'tint')?></li>
                        </ul>
                        <div class="whats-new-links-text left"><?php echo $whats_new_desc?></div><!--/whats-new-links-text-->
                    </div><!--/whats-new-links-->


           <?php $item_counter = 1;
            $args=array('post_type' => 'pt_portfolio', 'post_status' => 'publish', 'ignore_sticky_posts'=> 1,'posts_per_page'=> 3);
               query_posts($args);
                //The Loop
                if ( have_posts() ) : while ( have_posts() ) : the_post();?>

                    <div class="whats-new-one left"  <?php if ($item_counter == 1) {
                                echo 'style="margin-left: 0;"';
                            }?>>
                        <div class="whats-new-images left">
                            <a href="<?php echo wp_get_attachment_url( get_post_thumbnail_id() )?>" class="pirobox " title="<?php the_title(); ?>" rel="single">
                            <?php the_post_thumbnail('portfolio'); ?>
                            </a>
                        </div><!--/whats-new-images-->
                        <div class="whats-new-text-content left">
                            <div class="whats-new-title"><a href="<?php the_permalink()?>"><?php the_title() ?></a></div><!--/whats-new-title-->
                            <div class="whats-new-data"><?php echo get_the_category_list( '&nbsp; &nbsp;|&nbsp; &nbsp;', $post->ID ); ?></div><!--/whats-new-data-->
                        </div><!--/whats-new-text-content-->
                    </div><!--/whats-new-one-->

                 <?php
                     $item_counter++;
                     endwhile;
                     endif;?>

                </div><!--/whats-new-ajax-->

            </div><!--/whats-new-content-->

<?php }

        /*************************************************************/
        /************NEWSLETTER************************************/
        /*************************************************************/

?>

                     <?php
                     $newsletter_heading = get_option('newsletter_box_heading');
                     $newsletter_title = get_option('newsletter_box_title');
                     $newsletter_description = get_option('newsletter_box_description');
                        if(empty($newsletter_heading)) {$newsletter_heading = "SIGN-UP FOR THE NEWSLETTER";}
                        if(empty($newsletter_title)) {$newsletter_title = "Newsletter";}
                        if(empty($newsletter_description)) {$newsletter_description = "Sign up for free to get deals directly to your mailbox.";}

                    $newsletter_type = get_option('newsletter_newsletter_service');

                    $sendloop_username = get_option('newsletter_sendloop_username');
                    $sendloop_list_id = get_option('newsletter_sendloop_list_id');

                    if($newsletter_type !== false && $newsletter_type !== 'None'){?>

            <div class="sign-up-home left">
                <div class="point-border-title left"><h5><?php echo $newsletter_heading?></h5></div><!--/point-border-title-->

                <div class="sign-up-home-content left">
                    <div class="border-color left"></div>
                    <div class="sign-up-home-text left">
                        <div class="newsletter-home left">
                            <img src="<?php echo get_template_directory_uri()?>/style/img/sign-up-icon.png" alt="img" title="img" />
                            <span><?php echo $newsletter_title?></span>
                            <p><?php echo $newsletter_description?></p>
                        </div><!--/newsletter-home-->
                        <div class="home-form right">

                        <?php if($newsletter_type == 'Sendloop'){ ?>

                                <form action="http://<?php echo $sendloop_username ?>.sendloop.com/subscribe.php" method="post">
                                    <input type="text" name="FormValue_Fields[EmailAddress]" value="" id="FormValue_EmailAddress" class="newsletter_email" src="style/img/menu-contact.png"/>
                                    <input type="submit" name="FormButton_Subscribe" value="Submit" id="FormButton_Subscribe" class="newsletter_button"/>
                                    <input type="hidden" name="FormValue_ListID" value="<?php echo $sendloop_list_id ?>" id="FormValue_ListID" />
                                    <input type="hidden" name="FormValue_Command" value="Subscriber.Add" id="FormValue_Command" />
                                </form>

                    <?php  } elseif ($newsletter_type == 'Mailchimp'){ ?>

                                <?php get_template_part('script/mailchimp/mailchimp')?>

                    <?php }?>

                        </div><!--/home-form-->
                    </div><!--/sign-up-home-text-->
                </div><!--/sign-up-home-content-->
            </div><!--/sign-up-home-->

                    <?php }?>


        </div><!--/wrapper-->
    </div><!--/content-->

<?php get_footer(); ?>