<?php

function tk_comments($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment; ?>


<!-- ONE COMMENT -->

<div <?php comment_class(); ?>>
                        <div class="comment-start-one left">
                        <div class="comment-images"><?php echo get_avatar($comment,$size='35'); ?></div><!--/comment-images-->
                        <div class="comment-start-title left">
                            <span><?php echo $comment->comment_author ?></span>
                            <p><?php echo $comment->comment_date ?> <?php if ($comment->comment_approved == '0') : ?><?php _e('- Your comment is awaiting moderation.', 'tint') ?><?php endif; ?> <?php edit_comment_link(__(' - Edit - '),'  ','') ?> <?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?></p>
                        </div><!--/comment-start-title-->
                        <div class="comment-start-text left"><?php comment_text() ?></div><!--/comment-start-text-->
                    </div><!--/comment-start-one-->

</div><!--/comment-start-one-->


<?php } ?>


<!-- COMMENTS LIST -->

<div class="comment-start left">

    <div class="bg-single-title left"><h6><?php comments_number('No Comments', 'One Comment', '% Comments' );?></h6></div>

        <?php wp_list_comments('type=comment&callback=tk_comments'); ?>

</div>


<?php if ( comments_open() ) : ?>


        <?php if ( get_option('comment_registration') && !$user_ID ) : ?>
        <div class="comment-title left"><?php _e('You must be', 'tint')?> <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php echo urlencode(get_permalink()); ?>"><?php _e('logged in', 'tint') ?></a> <?php _e('to post a comment.', 'tint') ?></div>
                <?php else : ?>
        <div class="bg-single-title left"><h6><?php _e('Leave a Comment', 'tint')?> <?php echo $user_identity; ?> </h6></div>


<!-- FORM CHECKING -->


<script type="text/javascript">
function checkForm(){
    var errors = 0;

    if(jQuery('#comment').val() == '<?php _e('Message (required)', 'tint'); ?>'){
        jQuery('#message').html('Please insert your message');
        errors++;jQuery('#comment').focus();
    }

    if(jQuery('#email').val() == ''){
        jQuery('#message').html('Please insert your email');
        errors++;jQuery('#email').focus();
    }

    if(jQuery('#author').val() == ''){
        jQuery('#message').html('Please insert your name');
        errors++;jQuery('#author').focus();
    }

    if(errors == 0){
        return true;
    }else{
        return false;
    }
}
</script>


<!-- COMMENT FORM -->


<div class="sign-up-home-content blog-single-user-content left">
    <div class="border-color left"></div>
        <div class="form left">
            <form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform contact-form" onSubmit="return checkForm();">
                <?php if ( !$user_ID ){?>
                    <div class="bg-input left"><input class="contact_input_text" type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" name="author" id="author" value=""/><div class="form-text-input left"><?php if($req) echo _e('Name (required)', 'tint'); ?></div></div>
                    <div class="bg-input left"><input class="contact_input_text" type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" name="url" id="url" value=""/><div class="form-text-input left"><?php if($req) echo _e('URL', 'tint'); ?></div></div>
                    <div class="bg-input left"><input class="contact_input_text" type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" name="email" id="email" value=""/><div class="form-text-input left"><?php if($req) echo _e('E-mail (required)', 'tint'); ?></div></div>
                <?php }?>
                    <div class="form-textarea"><textarea onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" name="comment" id="comment" ><?php _e('Message (required)', 'tint'); ?></textarea></div><!--/form-textarea-->
                    <div id="message"></div>
                    <div class="form-button right"><input class="submit-button"  type="submit" name="submit-comment" value="Add Comment" /></div><!--/-button-->
                <?php comment_id_fields(); ?>
                <?php do_action('comment_form', $post->ID); ?>
            </form>
</div>
</div>

        <?php endif; ?>

<?php else : ?>

<div class="comment-title left">Comments are closed</div>

<?php endif; ?>