<?php
//loading wordpress functions
require( '../../../wp-load.php' );

                echo "<ul class='pagingx'>";
                $id = $_GET['id'];
                $paged = (get_query_var('paged')) ? get_query_var('paged') : 0;
                $args=array('cat'=>$id, 'post_type' => 'pt_portfolio',  'paged' => $paged, 'post_status' => 'publish', 'ignore_sticky_posts'=> 1,'posts_per_page'=>1000);

                //The Query
                $the_query = new WP_Query( $args );

                $item_counter=0;

                //The Loop
                if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post();?>


                <?php if ($item_counter % 4 ==0){echo '<div class="portfolio-row left">';}?>

                    <div class="whats-new-one left" <?php if ($item_counter % 4 ==0){echo 'style="margin-left: 0;"';}?>>
                        <div class="whats-new-images left"><a href="<?php echo wp_get_attachment_url( get_post_thumbnail_id() )?>" class="pirobox" title="<?php the_title(); ?>"><?php the_post_thumbnail('portfolio'); ?></a></div><!--/whats-new-images-->
                        <div class="whats-new-text-content left">
                            <div class="whats-new-title"><a href="<?php the_permalink()?>"><?php the_title() ?></a></div><!--/whats-new-title-->
                            <div class="whats-new-data"><?php echo get_the_category_list( '&nbsp; &nbsp;|&nbsp; &nbsp;', $post->ID ); ?></div><!--/whats-new-data-->
                        </div><!--/whats-new-text-content-->
                    </div><!--/whats-new-one-->


                        <?php
                        $item_counter++;
                         if ($item_counter % 4 ==0){echo '</div>';}
                        echo "</li>";
                    endwhile;
                    // Reset Post Data
                    wp_reset_postdata();
                    echo "</ul>";
                    ?>

                <?php else: ?>
                <?php endif;
                $numpages =get_option('general_portfolio_posts');
                $numpages =$numpages*3;
                ?>

        <?php
            $body_font = get_option('colors_body_font_color');
            $links_color = get_option('colors_links_color');
            $links_hover = get_option('colors_links_hover');
        ?>

                <script type="text/javascript">
                    //Ajax Pagination
                    $("ul.pagingx").quickPager(pageSize	= '<?php echo $numpages?>');
                    $(".simplePagerNav").attr('style', 'margin:0 0 33px; clear:both');
                </script>

                      <script type="text/javascript">
                        jQuery(document).ready(function(){

                                jQuery(".whats-new-title a").hover(function() {
                                        jQuery(this).animate({color: "#<?php echo $links_hover; ?>"},{duration:200,queue:false}, 'easeOutSine');
                                },function() {
                                        jQuery(this).animate({color: "#<?php echo $links_color; ?>"},{duration:300,queue:false}, 'easeOutSine');
                                });

                                jQuery(".whats-new-data a").hover(function() {
                                        jQuery(this).animate({color: "#<?php echo $links_hover; ?>"},{duration:200,queue:false}, 'easeOutSine');
                                },function() {
                                        jQuery(this).animate({color: "#<?php echo $body_font; ?>"},{duration:300,queue:false}, 'easeOutSine');
                                });

                                jQuery(".whats-new-portfolio-title a").hover(function() {
                                        jQuery(this).animate({color: "#<?php echo $links_hover; ?>"},{duration:200,queue:false}, 'easeOutSine');
                                },function() {
                                        jQuery(this).animate({color: "#<?php echo $links_color; ?>"},{duration:300,queue:false}, 'easeOutSine');
                                });


                                $('.piro_overlay,.pirobox_content').remove();
                                $().piroBox({
                                    my_speed: 300,
                                    bg_alpha:0.5,
                                    radius: 4,
                                    scrollImage : false,
                                    slideShow : 'true',
                                    slideSpeed : 3,
                                    pirobox_next : 'piro_next',
                                    pirobox_prev : 'piro_prev',
                                    close_all : '.piro_close'
                                });

                                jQuery('img','.pirobox').hover(function(){
                                    jQuery(this).stop().animate({
                                        opacity:0.4
                                    },500);
                                },function(){
                                    jQuery(this).stop().animate({
                                        opacity:1
                                    },300);
                                });

                        })
                        </script>
