<form method="get" id="searchform" action="<?php echo home_url()  ?>/">
    <div class="sidebar_holder">
	<input type="text" value="Search" onclick="value=''" name="s" id="s" class="search-input" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value=""/>
	<input type="submit" id="searchsubmit" class="search-submit-button" value="" />
    </div>
</form>
